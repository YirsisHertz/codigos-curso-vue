<template>
  <div class="container mt-3">
    <div class="card" style="width: 100%;">
      <div class="card-body">
        <h5 class="card-title">About</h5>
        <h6 class="card-subtitle mb-2 text-muted">Hecho por Yirsis Serrano</h6>
        <p class="card-text" style="text-align: justify;">
          Esta aplicación utiliza el API de
          <a href="http://giphy.com" target="_blank" rel="noopener noreferrer"
            >giphy.com</a
          >
        </p>
      </div>
    </div>
  </div>
</template>
