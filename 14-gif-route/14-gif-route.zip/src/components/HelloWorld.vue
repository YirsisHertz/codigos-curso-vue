<template>
  <div class="container mt-3">
    <div class="card" style="width: 100%;">
      <div class="card-body">
        <h5 class="card-title">Gif Router</h5>
        <h6 class="card-subtitle mb-2 text-muted">Hecho por Yirsis Serrano</h6>
        <p class="card-text" style="text-align: justify;">
          Esta aplicación es parte del curso de Vue 3 en Udemy y estamos
          aprendiendo a integrar Bootstrap, a trabajar con Rutas y muchas cosas
          más.
        </p>
      </div>
    </div>
  </div>
</template>
