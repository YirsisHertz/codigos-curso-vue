<template>
  <div class="home">
    <register />
  </div>
</template>

<script>
import Register from "../components/Register.vue";
export default {
  components: { Register },
  name: "Home",
};
</script>
