<template>
  <log-in />
</template>

<script>
import LogIn from "../components/LogIn.vue";
export default {
  components: { LogIn },
};
</script>
